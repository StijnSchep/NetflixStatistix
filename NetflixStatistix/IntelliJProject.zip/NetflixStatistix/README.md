# Application.NetflixStatistix
Repository for Netflix Statistix Java Swing application
