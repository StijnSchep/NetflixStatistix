package Business;

public enum PanelValue {
    // Values are used to switch to different panels in PanelSwitcher
    MAIN, SERIES, FILM, ACCOUNT
}
